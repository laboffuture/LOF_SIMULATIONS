/* SCORM 1.2 connection for a Lab of Future simulation.
   Tells the LMS that the learner opened the simulation (incomplete), when they completed it,
   and how long the session lasted. Outside an LMS it does nothing and the simulation runs as usual. */
(function () {
  "use strict";
  var cfg = window.SCORM_CFG || {};
  function findAPI(win) {
    for (var n = 0; win && n < 12; n++) {
      try {
        if (win.API) return win.API;
      } catch (e) {}
      if (!win.parent || win.parent === win) break;
      win = win.parent;
    }
    return null;
  }
  var api = findAPI(window);
  if (!api && window.opener) api = findAPI(window.opener);
  if (!api) return;

  var start = Date.now(),
    done = false,
    closed = false;
  api.LMSInitialize("");
  var status = api.LMSGetValue("cmi.core.lesson_status");
  if (status === "completed" || status === "passed") done = true;
  else api.LMSSetValue("cmi.core.lesson_status", "incomplete");
  api.LMSCommit("");

  function complete() {
    if (done) return;
    done = true;
    api.LMSSetValue("cmi.core.lesson_status", "completed");
    api.LMSCommit("");
  }

  // completion: the simulation's own end-of-run report appears, or enough active minutes have passed
  var active = 0,
    last = Date.now();
  setInterval(function () {
    var now = Date.now();
    if (!document.hidden) active += now - last;
    last = now;
    if (done) return;
    try {
      if (cfg.done && cfg.done()) complete();
    } catch (e) {}
    if (cfg.minutes && active >= cfg.minutes * 60000) complete();
  }, 1000);

  // session time in SCORM 1.2 format (HH:MM:SS)
  function span(ms) {
    var s = Math.floor(ms / 1000),
      h = Math.floor(s / 3600),
      m = Math.floor((s % 3600) / 60);
    s = s % 60;
    var p = function (v) {
      return (v < 10 ? "0" : "") + v;
    };
    return p(Math.min(h, 9999)) + ":" + p(m) + ":" + p(s);
  }
  function finish() {
    if (closed) return;
    closed = true;
    api.LMSSetValue("cmi.core.session_time", span(Date.now() - start));
    api.LMSCommit("");
    api.LMSFinish("");
  }
  window.addEventListener("pagehide", finish);
  window.addEventListener("beforeunload", finish);
})();
